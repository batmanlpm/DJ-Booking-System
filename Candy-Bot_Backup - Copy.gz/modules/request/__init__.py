"""
request module for handling song requests.
"""

from .request_cog import RequestCog, setup

__all__ = ['RequestCog', 'setup']
