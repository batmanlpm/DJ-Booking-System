"""
Welcome module for sending DMs to new members.
"""

from .welcome_cog import setup

__all__ = ['setup']
